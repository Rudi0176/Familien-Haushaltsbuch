
import { GoogleGenAI, Type } from "@google/genai";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getOnboardingResponse = async (messages: { role: 'user' | 'model', parts: { text: string }[] }[]) => {
  const ai = getAI();
  
  const systemInstruction = `
    DU BIST: Ein empathischer Finanz-Mentor und "guter Freund". Du hilfst einer Familie, ihr Onboarding in die Haushaltsbuch-App abzuschließen.

    DEIN AUFTRAG:
    Führe ein lockeres Interview. Stelle IMMER NUR EINE FRAGE nacheinander.
    Folge dieser Reihenfolge:
    1. Begrüßung & Familienstruktur (Erwachsene/Kinder).
    2. Wohnsituation (Miete/Eigentum).
    3. Mobilität (Auto/ÖPNV).
    4. Haustiere (Anzahl & Art).
    5. Ziele & Fokus (Sparziel, Notgroschen etc.).
    6. Schulden & Kredite (Restschuld & Zinssatz).

    WICHTIG: Sobald du ALLE Informationen gesammelt hast, fasse sie herzlich zusammen. 
    Hänge an deine letzte Nachricht UNBEDINGT einen JSON-Block an, der exakt so aussieht:
    {
      "familyName": "...",
      "adults": 0,
      "children": 0,
      "housingSituation": "Miete/Eigenheim",
      "carCount": 0,
      "publicTransportSubCount": 0,
      "petCount": 0,
      "financialFocus": "...",
      "monthlySavingsGoal": 500,
      "debtAmount": 0,
      "interestRate": 0
    }
    Nutze deutsche Begriffe für die Auswahlfelder.

    TONFALL: Herzlich, motivierend, locker. Keine Bank-Sprache.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: messages,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Ups, da gab es ein technisches Problem. Können wir den letzten Schritt kurz wiederholen?";
  }
};

export const getFinancialAdvice = async (messages: { role: 'user' | 'model', parts: { text: string }[] }[], transactionsSummary: string, familyContext: string) => {
  const ai = getAI();
  
  const systemInstruction = `
    DU BIST: Ein hochqualifizierter, empathischer Finanz-Mentor für Familien. Dein Ziel ist es, nicht nur Zahlen zu verwalten, sondern das finanzielle Wohlbefinden der gesamten Familie nachhaltig zu verbessern.

    DEIN ANALYSE-STIL:
    1. GEHE IN DIE TIEFE: Schau dir nicht nur Summen an. Suche nach Mustern.
    2. PSYCHOLOGIE: Verstehe den emotionalen Kontext von Ausgaben.
    3. STRATEGISCH: Unterscheide strikt zwischen Fixkosten und variablen Kosten.
    4. INTERAKTIV: Beende JEDE Antwort mit 1-2 gezielten Rückfragen.

    DEIN TONFALL: Warm, unterstützend, locker. Nutze "Ihr/Euch".

    FAMILIEN-PROFIL:
    ${familyContext}

    AKTUELLER DATEN-KONTEXT:
    ${transactionsSummary}
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: messages,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.8,
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Hoppla, da ist ein Fehler aufgetreten. Könntet ihr die Frage noch einmal stellen?";
  }
};

export const analyzeReceipt = async (imageBase64: string, categories: string[]) => {
  const ai = getAI();
  
  const prompt = `Analysiere diesen Beleg...`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        {
          parts: [
            { text: prompt },
            {
              inlineData: {
                mimeType: "image/jpeg",
                data: imageBase64
              }
            }
          ]
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              amount: { type: Type.NUMBER, description: "Der extrahierte Betrag" },
              description: { type: Type.STRING, description: "Kurze Beschreibung des Kaufs" },
              category: { type: Type.STRING, description: "Die am besten passende Kategorie aus der Liste" },
              type: { type: Type.STRING, description: "'Ausgabe' oder 'Einnahme'" }
            },
            required: ["amount", "description", "category", "type"]
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("Keine Antwort von der KI");
    return JSON.parse(text);
  } catch (error) {
    console.error("Receipt Analysis Error:", error);
    return null;
  }
};
