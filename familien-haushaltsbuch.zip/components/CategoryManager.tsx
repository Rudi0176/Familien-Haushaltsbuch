
import React, { useState } from 'react';
import { Tag, Plus, Trash2, AlertCircle } from 'lucide-react';

interface Props {
  categories: string[];
  onAdd: (name: string) => void;
  onDelete: (name: string) => void;
}

const CategoryManager: React.FC<Props> = ({ categories, onAdd, onDelete }) => {
  const [newName, setNewName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newName.trim()) {
      onAdd(newName.trim());
      setNewName('');
    }
  };

  return (
    <div className="space-y-8 max-w-3xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header>
        <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight">Kategorien</h2>
        <p className="text-slate-500 font-medium mt-1">Strukturiere deine Finanzen für bessere Analysen</p>
      </header>

      <div className="bg-white p-8 rounded-[12px] shadow-sm border border-slate-100">
        <div className="flex items-center gap-3 mb-8">
          <div className="p-2 bg-violet-50 text-violet-600 rounded-lg"><Tag size={20} /></div>
          <h3 className="font-bold text-slate-800 tracking-tight">Kategorien verwalten</h3>
        </div>

        <form onSubmit={handleSubmit} className="flex gap-3 mb-10">
          <input
            type="text"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Neue Kategorie hinzufügen..."
            className="flex-1 px-5 py-4 rounded-xl border-2 border-slate-100 focus:border-violet-500 bg-slate-50/50 outline-none font-semibold transition-all"
          />
          <button
            type="submit"
            className="bg-violet-600 text-white px-6 py-4 rounded-xl hover:bg-violet-700 active:scale-95 transition-all shadow-lg shadow-violet-200 flex items-center gap-2 font-bold"
          >
            <Plus size={20} /> <span className="hidden sm:inline">Hinzufügen</span>
          </button>
        </form>

        <div className="space-y-4">
          <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-4">Aktive Kategorien</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map((cat) => (
              <div
                key={cat}
                className="flex items-center justify-between p-4 bg-white rounded-xl border border-slate-100 hover:border-violet-200 hover:shadow-sm transition-all group"
              >
                <span className="font-bold text-slate-700 text-sm">{cat}</span>
                {cat !== 'Sonstiges' && (
                  <button
                    onClick={() => onDelete(cat)}
                    className="p-2 text-slate-300 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all active:scale-90 opacity-0 group-hover:opacity-100"
                    title="Kategorie löschen"
                  >
                    <Trash2 size={16} />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-indigo-50 p-6 rounded-[12px] border border-indigo-100 flex gap-4 text-indigo-900">
        <AlertCircle size={24} className="shrink-0 text-indigo-500" />
        <div className="space-y-1">
          <p className="font-bold text-sm">Pro-Tipp für die KI</p>
          <p className="text-xs leading-relaxed opacity-80">
            Detaillierte Kategorien wie "Streaming-Abos" oder "Bücher" statt nur "Freizeit" helfen eurem KI-Mentor, präzisere Sparvorschläge zu machen.
          </p>
        </div>
      </div>
    </div>
  );
};

export default CategoryManager;
