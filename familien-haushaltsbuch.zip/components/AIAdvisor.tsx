
import React, { useState, useRef, useEffect } from 'react';
import { Transaction, TransactionType, FamilySettings } from '../types';
import { getFinancialAdvice } from '../services/gemini';
import { Sparkles, Loader2, Send, MessageCircle, User, Bot, RefreshCcw, Coffee, ShoppingBag, ShieldCheck } from 'lucide-react';

interface Props {
  transactions: Transaction[];
  settings: FamilySettings;
}

interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

const AIAdvisor: React.FC<Props> = ({ transactions, settings }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const getTransactionsSummary = () => {
    if (transactions.length === 0) return "Keine Transaktionen vorhanden.";
    const cats: Record<string, number> = {};
    let inc = 0, exp = 0;
    transactions.forEach(t => {
      cats[t.category] = (cats[t.category] || 0) + t.amount;
      if (t.type === TransactionType.INCOME) inc += t.amount; else exp += t.amount;
    });
    return `Status: +${inc}€, -${exp}€, Saldo: ${inc-exp}€. Kategorien: ${Object.entries(cats).map(([k,v])=>`${k}: ${v}€`).join(', ')}`;
  };

  const getFamilyContext = () => {
    return `Familie: ${settings.familyName}, Erwachsene: ${settings.adults}, Kinder: ${settings.children}, Sparziel: ${settings.monthlySavingsGoal}€, Fokus: ${settings.financialFocus}, Wohnsituation: ${settings.housingSituation}, Haustiere: ${settings.petCount}, PKW: ${settings.carCount}, ÖPNV-Abos: ${settings.publicTransportSubCount}`;
  };

  const startAnalysis = async (userText?: string) => {
    const textToSend = userText || "Hallo Coach! Analysiere bitte unser Budget basierend auf unserem Familienprofil.";
    const newMessages: ChatMessage[] = [...messages, { role: 'user', text: textToSend }];
    setMessages(newMessages);
    setInputText('');
    setLoading(true);
    const summary = getTransactionsSummary();
    const familyContext = getFamilyContext();
    const advice = await getFinancialAdvice(newMessages.map(m=>({role:m.role, parts:[{text:m.text}]})), summary, familyContext);
    if (advice) setMessages(prev => [...prev, { role: 'model', text: advice }]);
    setLoading(false);
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || loading) return;
    startAnalysis(inputText);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] max-w-5xl mx-auto rounded-[12px] overflow-hidden bg-white shadow-2xl border border-slate-100 animate-in zoom-in-95 duration-500">
      {/* Premium Header */}
      <div className="bg-gradient-to-r from-violet-700 via-indigo-700 to-violet-800 p-6 text-white flex justify-between items-center shrink-0">
        <div className="flex items-center gap-5">
          <div className="bg-white/10 p-3 rounded-2xl backdrop-blur-xl border border-white/20 shadow-inner">
            <Sparkles className="text-yellow-300 fill-yellow-300" size={28} />
          </div>
          <div>
            <h2 className="font-black text-xl tracking-tight leading-tight">Finanz-Mentor AI</h2>
            <div className="flex items-center gap-2 mt-0.5 opacity-80">
              <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse shadow-emerald-400 shadow-sm" />
              <p className="text-[10px] font-black uppercase tracking-[0.2em]">Profil geladen: Familie {settings.familyName}</p>
            </div>
          </div>
        </div>
        <button onClick={() => setMessages([])} className="p-3 hover:bg-white/10 rounded-xl transition-colors text-white/50 hover:text-white">
          <RefreshCcw size={20} />
        </button>
      </div>

      {/* Chat Area */}
      <div className="flex-1 bg-[#fcfdff] overflow-y-auto p-6 md:p-8 space-y-8 custom-scrollbar">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-8 max-w-md mx-auto">
            <div className="w-28 h-28 bg-violet-50 rounded-[28px] flex items-center justify-center text-violet-600 shadow-inner">
              <MessageCircle size={56} strokeWidth={1.2} />
            </div>
            <div>
              <h3 className="text-3xl font-extrabold text-slate-800 tracking-tight mb-3">Hi! Ich bin euer Mentor.</h3>
              <p className="text-slate-500 font-medium leading-relaxed">
                Ich kenne euer Profil ({settings.adults} Erw., {settings.children} Kinder) und helfe euch, euer Sparziel von {settings.monthlySavingsGoal}€ zu erreichen.
              </p>
            </div>
            <button
              onClick={() => startAnalysis()}
              className="w-full bg-violet-600 text-white px-8 py-5 rounded-xl font-black shadow-xl shadow-violet-200 hover:bg-violet-700 active:scale-95 transition-all flex items-center justify-center gap-3 text-lg"
            >
              Maßgeschneiderte Analyse <Sparkles size={22} />
            </button>
          </div>
        ) : (
          <>
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex gap-5 ${msg.role === 'user' ? 'flex-row-reverse' : ''} animate-in fade-in slide-in-from-bottom-4`}>
                <div className={`shrink-0 w-12 h-12 rounded-xl flex items-center justify-center shadow-sm ${msg.role === 'user' ? 'bg-violet-600 text-white' : 'bg-white text-violet-600 border border-violet-100'}`}>
                  {msg.role === 'user' ? <User size={24} /> : <Bot size={24} />}
                </div>
                <div className={`max-w-[80%] p-6 rounded-2xl shadow-sm leading-relaxed ${
                  msg.role === 'user' 
                    ? 'bg-violet-600 text-white rounded-tr-none font-medium' 
                    : 'bg-white text-slate-800 rounded-tl-none border border-slate-100 font-medium'
                }`}>
                   <p className="whitespace-pre-line text-sm md:text-base">{msg.text}</p>
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex gap-5 animate-pulse">
                <div className="shrink-0 w-12 h-12 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-400">
                  <Loader2 className="animate-spin" size={24} />
                </div>
                <div className="bg-white p-6 rounded-2xl rounded-tl-none border border-slate-100 text-slate-400 text-sm shadow-sm italic">
                  Berücksichtige euer Profil (Tiere & Autos)...
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </>
        )}
      </div>

      {/* Input & QuickActions */}
      <div className="p-6 bg-white border-t border-slate-100 space-y-4">
        {messages.length > 0 && !loading && (
          <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar scroll-smooth">
             <QuickBtn icon={ShoppingBag} label="Lebensmittel-Check" onClick={() => startAnalysis("Wie sieht unser Budget für Lebensmittel aus? Wo können wir sparen?")} />
             <QuickBtn icon={ShieldCheck} label="Fixkosten-Plan" onClick={() => startAnalysis("Analysiere unsere Fixkosten. Gibt es dort überflüssige Posten?")} />
             <QuickBtn icon={Coffee} label="Konsum-Muster" onClick={() => startAnalysis("Gibt es kleine Ausgaben, die sich diesen Monat summieren?")} />
          </div>
        )}
        <form onSubmit={handleSend} className="flex gap-4 max-w-4xl mx-auto relative">
          <input
            type="text" value={inputText} onChange={(e) => setInputText(e.target.value)}
            disabled={loading || messages.length === 0}
            placeholder={messages.length === 0 ? "Nutze den Button oben..." : "Stelle eine Frage zu euren Finanzen..."}
            className="flex-1 bg-slate-50 border-2 border-transparent focus:border-violet-500 focus:bg-white rounded-xl px-6 py-4 outline-none font-semibold transition-all disabled:opacity-50"
          />
          <button
            type="submit" disabled={!inputText.trim() || loading}
            className="bg-violet-600 text-white p-4 rounded-xl shadow-lg shadow-violet-100 hover:bg-violet-700 active:scale-95 transition-all disabled:opacity-50 shrink-0"
          >
            <Send size={24} />
          </button>
        </form>
      </div>
    </div>
  );
};

const QuickBtn = ({ icon: Icon, label, onClick }: any) => (
  <button onClick={onClick} className="flex items-center gap-2 px-4 py-2.5 bg-slate-50 hover:bg-violet-50 hover:text-violet-700 border border-slate-200 rounded-xl text-[11px] font-black uppercase tracking-tight transition-all shrink-0 active:scale-95">
    <Icon size={14} /> {label}
  </button>
);

export default AIAdvisor;
