
import React, { useState } from 'react';
import { Transaction, TransactionType } from '../types';
import { Trash2, Search, RefreshCw, Edit2, Filter, Sparkles, PlusCircle } from 'lucide-react';

interface Props {
  transactions: Transaction[];
  onDelete: (id: string) => void;
  onEdit: (t: Transaction) => void;
}

const TransactionList: React.FC<Props> = ({ transactions, onDelete, onEdit }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showOnlyRecurring, setShowOnlyRecurring] = useState(false);
  
  const filtered = transactions.filter(t => {
    const matchesSearch = t.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          t.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRecurring = showOnlyRecurring ? t.isRecurring : true;
    return matchesSearch && matchesRecurring;
  });

  const formatter = new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' });

  // Farbleitsystem Map
  const categoryColors: Record<string, string> = {
    'Lebensmittel': 'bg-emerald-100 text-emerald-600',
    'Miete/Wohnen': 'bg-indigo-100 text-indigo-600',
    'Mobilität': 'bg-blue-100 text-blue-600',
    'Haustiere': 'bg-rose-100 text-rose-600',
    'Freizeit': 'bg-amber-100 text-amber-600',
    'Versicherungen': 'bg-slate-100 text-slate-600',
    'Gehalt': 'bg-emerald-600 text-white',
    'Sparen': 'bg-violet-100 text-violet-600'
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-4 mb-6 no-print">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold text-slate-800">Verlauf & Verwaltung</h2>
          <button 
            onClick={() => setShowOnlyRecurring(!showOnlyRecurring)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${showOnlyRecurring ? 'bg-indigo-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}`}
          >
            <RefreshCw size={14} className={showOnlyRecurring ? 'animate-spin-slow' : ''} />
            {showOnlyRecurring ? 'Alle anzeigen' : 'Nur Fixkosten'}
          </button>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input
            type="text"
            placeholder="Beschreibungen oder Kategorien suchen..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm shadow-sm"
          />
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden min-h-[400px]">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center p-12 text-center h-full space-y-6">
            <div className="w-24 h-24 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-200">
               <PlusCircle size={48} strokeWidth={1} />
            </div>
            <div className="max-w-xs">
              <p className="text-slate-500 font-bold mb-2">Noch keine Ausgaben?</p>
              <div className="p-4 bg-violet-50 rounded-xl border border-violet-100 text-violet-700 text-xs flex gap-3 items-start text-left">
                <Sparkles size={16} className="shrink-0 mt-0.5" />
                <p className="leading-relaxed">
                  Scanne deinen ersten Beleg oder trage eine Buchung manuell ein, damit ich dir helfen kann, euer Spar-Jahr erfolgreich zu machen!
                </p>
              </div>
            </div>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {filtered.map(t => (
              <div key={t.id} className="p-4 flex items-center justify-between group hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-3 sm:gap-4 overflow-hidden">
                  <div className={`shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-xs font-black shadow-sm ${
                    categoryColors[t.category] || (t.type === TransactionType.INCOME ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-600')
                  }`}>
                    {t.category[0]}
                  </div>
                  <div className="overflow-hidden">
                    <div className="flex items-center gap-2">
                      <p className="font-semibold text-slate-800 truncate text-sm">{t.description}</p>
                      {t.isRecurring && (
                        <span className="shrink-0 flex items-center gap-0.5 px-1.5 py-0.5 bg-indigo-50 text-indigo-600 text-[8px] rounded uppercase font-black border border-indigo-100 tracking-widest">
                          Fix
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{t.category} • {new Date(t.date).toLocaleDateString('de-DE')}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2 sm:gap-4">
                  <p className={`font-black whitespace-nowrap text-sm sm:text-base tracking-tighter ${
                    t.type === TransactionType.INCOME ? 'text-emerald-600' : 'text-slate-800'
                  }`}>
                    {t.type === TransactionType.EXPENSE ? '-' : ''}{formatter.format(t.amount)}
                  </p>
                  <div className="flex items-center no-print opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => { e.stopPropagation(); onEdit(t); }}
                      className="p-2 text-slate-300 hover:text-indigo-600 transition-colors rounded-lg hover:bg-indigo-50"
                    >
                      <Edit2 size={16} />
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); onDelete(t.id); }}
                      className="p-2 text-slate-300 hover:text-rose-600 transition-colors rounded-lg hover:bg-rose-50"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {showOnlyRecurring && (
        <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-xl text-indigo-700 text-[10px] font-bold uppercase tracking-widest flex gap-3 items-center">
          <Filter size={14} className="shrink-0" />
          <p>Tipp: Fixkosten sind die Hebel für eure Sparrate. Prüfe regelmäßig eure Abos!</p>
        </div>
      )}
    </div>
  );
};

export default TransactionList;
