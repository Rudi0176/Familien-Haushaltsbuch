
import React from 'react';
import { FamilySettings } from '../types';
import { Users, Target, Home, Info, Save, PawPrint, Car, Bus, CreditCard } from 'lucide-react';

interface Props {
  settings: FamilySettings;
  onUpdate: (s: FamilySettings) => void;
}

const Settings: React.FC<Props> = ({ settings, onUpdate }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    onUpdate({
      ...settings,
      [name]: name === 'familyName' || name === 'financialFocus' || name === 'housingSituation' ? value : Number(value)
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10 animate-in fade-in slide-in-from-bottom-6 duration-500">
      <header>
        <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight">Persönliche Einstellungen</h2>
        <p className="text-slate-500 font-medium mt-1">Konfiguriere euer Familienprofil für präzisere KI-Analysen.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Familien-Struktur */}
        <section className="bg-white p-8 rounded-[12px] shadow-sm border border-slate-100 space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg"><Users size={20} /></div>
            <h3 className="font-bold text-slate-800 tracking-tight text-lg">Eure Familie</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2">Nachname der Familie</label>
              <input 
                type="text" name="familyName" value={settings.familyName} onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-violet-500 outline-none font-bold bg-slate-50/50"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2">Erwachsene</label>
                <input 
                  type="number" name="adults" min="1" value={settings.adults} onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-violet-500 outline-none font-bold bg-slate-50/50"
                />
              </div>
              <div>
                <label className="block text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2">Kinder</label>
                <input 
                  type="number" name="children" min="0" value={settings.children} onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-violet-500 outline-none font-bold bg-slate-50/50"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Finanzielle Ziele */}
        <section className="bg-white p-8 rounded-[12px] shadow-sm border border-slate-100 space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg"><Target size={20} /></div>
            <h3 className="font-bold text-slate-800 tracking-tight text-lg">Ziele & Fokus</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2">Monatliches Sparziel (€)</label>
              <input 
                type="number" name="monthlySavingsGoal" min="0" value={settings.monthlySavingsGoal} onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-violet-500 outline-none font-bold bg-slate-50/50"
              />
            </div>
            <div>
              <label className="block text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2">Aktueller Fokus</label>
              <select 
                name="financialFocus" value={settings.financialFocus} onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-violet-500 outline-none font-bold bg-slate-50/50 appearance-none"
              >
                <option value="Notgroschen aufbauen">Notgroschen aufbauen</option>
                <option value="Schulden abbauen">Schulden abbauen</option>
                <option value="Für Urlaub sparen">Für Urlaub sparen</option>
                <option value="Eigenkapital bilden">Eigenkapital bilden</option>
                <option value="Einfach nur Überblick behalten">Einfach Überblick behalten</option>
              </select>
            </div>
          </div>
        </section>

        {/* Kredite & Schulden */}
        <section className="bg-white p-8 rounded-[12px] shadow-sm border border-slate-100 space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-amber-50 text-amber-600 rounded-lg"><CreditCard size={20} /></div>
            <h3 className="font-bold text-slate-800 tracking-tight text-lg">Kredite & Schulden</h3>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2">Restschuld (€)</label>
              <input 
                type="number" name="debtAmount" min="0" value={settings.debtAmount} onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-violet-500 outline-none font-bold bg-slate-50/50"
              />
            </div>
            <div>
              <label className="block text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2">Ø Zins (%)</label>
              <input 
                type="number" name="interestRate" step="0.1" min="0" value={settings.interestRate} onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-violet-500 outline-none font-bold bg-slate-50/50"
              />
            </div>
          </div>
        </section>

        {/* Haustiere & Mobilität */}
        <section className="bg-white p-8 rounded-[12px] shadow-sm border border-slate-100 space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-rose-50 text-rose-600 rounded-lg"><PawPrint size={20} /></div>
            <h3 className="font-bold text-slate-800 tracking-tight text-lg">Haustiere</h3>
          </div>
          <div>
            <label className="block text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2">Anzahl der Haustiere</label>
            <input 
              type="number" name="petCount" min="0" value={settings.petCount} onChange={handleChange}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-violet-500 outline-none font-bold bg-slate-50/50"
            />
          </div>
        </section>

        {/* Wohnsituation */}
        <section className="bg-white p-8 rounded-[12px] shadow-sm border border-slate-100 space-y-6 md:col-span-2">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-violet-50 text-violet-600 rounded-lg"><Home size={20} /></div>
            <h3 className="font-bold text-slate-800 tracking-tight text-lg">Wohnsituation</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-end">
            <div>
              <label className="block text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2">Status</label>
              <div className="flex gap-4">
                {['Miete', 'Eigenheim'].map(option => (
                  <button
                    key={option}
                    type="button"
                    onClick={() => onUpdate({...settings, housingSituation: option})}
                    className={`flex-1 py-4 rounded-xl font-bold border-2 transition-all ${settings.housingSituation === option ? 'border-violet-600 bg-violet-50 text-violet-700' : 'border-slate-100 bg-slate-50 text-slate-400 hover:border-slate-200'}`}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="bg-amber-50 border border-amber-100 p-4 rounded-xl flex gap-3 text-amber-900">
              <Info size={18} className="shrink-0 text-amber-500 mt-1" />
              <p className="text-xs leading-relaxed font-medium">
                Diese Informationen helfen der KI zu verstehen, ob Fixkosten wie Nebenkosten, Instandhaltung oder Versicherungen für eure Situation angemessen sind.
              </p>
            </div>
          </div>
        </section>
      </div>

      <div className="flex justify-center pt-6">
        <button 
          onClick={() => {
            localStorage.removeItem('family_budget_onboarding_done');
            window.location.reload();
          }}
          className="text-[10px] text-slate-400 hover:text-rose-500 font-bold uppercase tracking-widest transition-colors underline decoration-dotted"
        >
          Onboarding neu starten (Daten zurücksetzen)
        </button>
      </div>
    </div>
  );
};

export default Settings;
