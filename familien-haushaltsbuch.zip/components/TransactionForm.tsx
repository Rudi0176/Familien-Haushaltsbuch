
import React, { useState, useEffect, useRef } from 'react';
import { Transaction, TransactionType, Category } from '../types';
import { RefreshCw, X, Plus, Check, ChevronDown, Camera, Loader2, Sparkles, CheckCircle2, Star } from 'lucide-react';
import { analyzeReceipt } from '../services/gemini';

interface Props {
  categories: Category[];
  onAdd: (t: Omit<Transaction, 'id'>) => void;
  onUpdate: (id: string, t: Omit<Transaction, 'id'>) => void;
  onAddCategory: (name: string) => void;
  editData: Transaction | null;
  onCancel: () => void;
}

const TransactionForm: React.FC<Props> = ({ categories, onAdd, onUpdate, onAddCategory, editData, onCancel }) => {
  const [type, setType] = useState<TransactionType>(TransactionType.EXPENSE);
  const [amount, setAmount] = useState<string>('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<Category>(categories[0] || 'Sonstiges');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [isRecurring, setIsRecurring] = useState(false);

  const [isAddingNewCategory, setIsAddingNewCategory] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');
  
  const [isScanning, setIsScanning] = useState(false);
  const [scanResultCount, setScanResultCount] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Top Kategorien Favoriten
  const favorites = ['Lebensmittel', 'Mobilität', 'Freizeit', 'Wohnen'].filter(f => categories.includes(f));

  useEffect(() => {
    if (editData) {
      setType(editData.type);
      setAmount(editData.amount.toString());
      setDescription(editData.description);
      setCategory(editData.category);
      setDate(editData.date);
      setIsRecurring(editData.isRecurring);
    } else {
      setType(TransactionType.EXPENSE);
      setAmount('');
      setDescription('');
      if (!isAddingNewCategory) {
        setCategory(categories.includes('Sonstiges') ? 'Sonstiges' : categories[0]);
      }
      setDate(new Date().toISOString().split('T')[0]);
      setIsRecurring(false);
    }
  }, [editData, categories]);

  const handleAddNewCategory = () => {
    if (newCategoryName.trim()) {
      onAddCategory(newCategoryName.trim());
      setCategory(newCategoryName.trim());
      setNewCategoryName('');
      setIsAddingNewCategory(false);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsScanning(true);
    setScanResultCount(null);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = (reader.result as string).split(',')[1];
        const results = await analyzeReceipt(base64String, categories);
        
        if (Array.isArray(results) && results.length > 0) {
          setScanResultCount(results.length);
          
          for (let i = 0; i < results.length - 1; i++) {
            const res = results[i];
            onAdd({
              amount: res.amount,
              description: res.description,
              category: categories.includes(res.category) ? res.category : 'Sonstiges',
              type: res.type === 'Einnahme' ? TransactionType.INCOME : TransactionType.EXPENSE,
              date: date,
              isRecurring: false
            });
          }

          const last = results[results.length - 1];
          setAmount(last.amount.toString());
          setDescription(last.description);
          setCategory(categories.includes(last.category) ? last.category : 'Sonstiges');
          setType(last.type === 'Einnahme' ? TransactionType.INCOME : TransactionType.EXPENSE);
        }
        setIsScanning(false);
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error("Scanning error:", error);
      setIsScanning(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || parseFloat(amount) <= 0) return;
    const data = { type, amount: parseFloat(amount), description: description || category, category, date, isRecurring };
    if (editData) onUpdate(editData.id, data); else onAdd(data);
    
    setAmount('');
    setDescription('');
    setIsRecurring(false);
    setScanResultCount(null);
  };

  return (
    <div className="max-w-xl mx-auto bg-white p-10 rounded-[12px] shadow-lg border border-slate-100 animate-in slide-in-from-bottom-6 duration-500">
      <div className="flex justify-between items-start mb-8">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">
            {editData ? 'Buchung anpassen' : 'Neue Buchung'}
          </h2>
          <p className="text-slate-400 text-sm mt-1 font-medium italic">Manuell eintragen oder Beleg scannen</p>
        </div>
        {!editData && (
          <button 
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isScanning}
            className={`flex flex-col items-center gap-1.5 p-3 rounded-2xl border-2 border-dashed transition-all group ${isScanning ? 'bg-violet-50 border-violet-200 text-violet-400' : 'bg-slate-50 border-slate-200 hover:border-violet-400 hover:bg-violet-50 text-slate-400 hover:text-violet-600'}`}
          >
            {isScanning ? <Loader2 size={24} className="animate-spin" /> : <Camera size={24} className="group-hover:scale-110 transition-transform" />}
            <span className="text-[10px] font-black uppercase tracking-widest">{isScanning ? 'Scannt...' : 'Beleg Scan'}</span>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              capture="environment"
              onChange={handleFileChange} 
            />
          </button>
        )}
        {editData && (
          <button onClick={onCancel} className="p-2.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-50 transition-colors">
            <X size={24} />
          </button>
        )}
      </div>
      
      {isScanning && (
        <div className="mb-8 p-6 bg-violet-600 rounded-2xl text-white shadow-xl shadow-violet-200 animate-pulse flex items-center gap-4">
          <Sparkles className="shrink-0" size={32} />
          <div>
            <p className="font-black text-lg leading-tight">KI analysiert Foto...</p>
            <p className="text-xs text-violet-100 font-medium opacity-80 uppercase tracking-widest">Suche nach allen Quittungen und Posten</p>
          </div>
        </div>
      )}

      {scanResultCount !== null && !isScanning && scanResultCount > 1 && (
        <div className="mb-8 p-5 bg-emerald-50 border border-emerald-100 rounded-2xl text-emerald-800 flex items-center gap-4 animate-in fade-in zoom-in-95">
          <CheckCircle2 className="text-emerald-500 shrink-0" size={28} />
          <div>
            <p className="font-bold">Super! {scanResultCount} Buchungen gefunden.</p>
            <p className="text-xs opacity-80 font-medium">Die ersten {scanResultCount - 1} wurden bereits gespeichert. Die letzte siehst du hier:</p>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="flex p-1.5 bg-slate-100 rounded-xl">
          <button
            type="button"
            onClick={() => setType(TransactionType.EXPENSE)}
            className={`flex-1 py-3 text-sm font-bold rounded-lg transition-all ${type === TransactionType.EXPENSE ? 'bg-white text-rose-500 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Ausgabe
          </button>
          <button
            type="button"
            onClick={() => setType(TransactionType.INCOME)}
            className={`flex-1 py-3 text-sm font-bold rounded-lg transition-all ${type === TransactionType.INCOME ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
          >
            Einnahme
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <label className="block text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2.5">Betrag (€)</label>
            <input
              type="number" step="0.01" inputMode="decimal" required
              value={amount} onChange={e => setAmount(e.target.value)}
              className="w-full px-5 py-4 rounded-xl border-2 border-slate-100 focus:border-violet-500 outline-none transition-all text-2xl font-black bg-slate-50/50"
              placeholder="0,00"
            />
          </div>

          <div>
            <label className="block text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2.5">Datum</label>
            <input
              type="date" required
              value={date} onChange={e => setDate(e.target.value)}
              className="w-full px-5 py-4 rounded-xl border-2 border-slate-100 focus:border-violet-500 outline-none font-bold bg-slate-50/50"
            />
          </div>
        </div>

        <div>
          <label className="block text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2.5">Favoriten</label>
          <div className="flex flex-wrap gap-2 mb-2">
            {favorites.map(fav => (
              <button
                key={fav}
                type="button"
                onClick={() => setCategory(fav)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all border ${category === fav ? 'bg-violet-600 border-violet-600 text-white' : 'bg-white border-slate-200 text-slate-500 hover:border-violet-400 hover:text-violet-600'}`}
              >
                <Star size={10} fill={category === fav ? "currentColor" : "none"} /> {fav}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2.5">Beschreibung</label>
          <input
            type="text" required
            value={description} onChange={e => setDescription(e.target.value)}
            className="w-full px-5 py-4 rounded-xl border-2 border-slate-100 focus:border-violet-500 outline-none font-semibold bg-slate-50/50"
            placeholder="Supermarkt, Miete, Gehalt..."
          />
        </div>

        <div>
          <label className="block text-[11px] font-black text-slate-400 uppercase tracking-widest mb-2.5">Kategorie</label>
          {isAddingNewCategory ? (
            <div className="flex gap-3 animate-in fade-in slide-in-from-right-2 duration-300">
              <input
                type="text" autoFocus value={newCategoryName}
                onChange={(e) => setNewCategoryName(e.target.value)}
                placeholder="Name der Kategorie..."
                className="flex-1 px-5 py-4 rounded-xl border-2 border-violet-200 bg-violet-50/30 outline-none font-bold focus:border-violet-500"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') { e.preventDefault(); handleAddNewCategory(); }
                  if (e.key === 'Escape') setIsAddingNewCategory(false);
                }}
              />
              <button
                type="button" onClick={handleAddNewCategory}
                className="bg-emerald-500 text-white p-4 rounded-xl shadow-lg shadow-emerald-100 hover:bg-emerald-600 active:scale-95 transition-all"
              >
                <Check size={24} />
              </button>
              <button
                type="button" onClick={() => setIsAddingNewCategory(false)}
                className="bg-slate-100 text-slate-500 p-4 rounded-xl hover:bg-slate-200 active:scale-95 transition-all"
              >
                <X size={24} />
              </button>
            </div>
          ) : (
            <div className="flex gap-3">
              <div className="flex-1 relative">
                <select
                  value={category} onChange={e => setCategory(e.target.value)}
                  className="w-full px-5 py-4 rounded-xl border-2 border-slate-100 bg-slate-50/50 outline-none font-bold appearance-none focus:border-violet-500 transition-colors"
                >
                  {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                </select>
                <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400"><ChevronDown size={18}/></div>
              </div>
              <button
                type="button" onClick={() => setIsAddingNewCategory(true)}
                className="bg-white text-violet-600 p-4 rounded-xl border-2 border-slate-100 hover:border-violet-200 transition-all shadow-sm active:scale-95"
                title="Neue Kategorie"
              >
                <Plus size={24} />
              </button>
            </div>
          )}
        </div>

        <div 
          className={`flex items-center gap-4 p-5 rounded-xl border cursor-pointer transition-all ${isRecurring ? 'bg-violet-50 border-violet-100' : 'bg-slate-50 border-slate-100'}`}
          onClick={() => setIsRecurring(!isRecurring)}
        >
          <div className={`w-12 h-6 rounded-full p-1 transition-colors relative ${isRecurring ? 'bg-violet-600' : 'bg-slate-300'}`}>
            <div className={`w-4 h-4 bg-white rounded-full transition-transform ${isRecurring ? 'translate-x-6' : 'translate-x-0'} shadow-sm`} />
          </div>
          <div className="flex-1">
            <p className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <RefreshCw size={14} className={isRecurring ? 'animate-spin-slow text-violet-600' : 'text-slate-400'} />
              Wiederkehrende Buchung
            </p>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Wird jeden Monat automatisch berechnet</p>
          </div>
        </div>

        <button
          type="submit"
          className={`w-full py-5 px-4 rounded-xl text-white text-lg font-black transition-all active:scale-[0.98] shadow-xl ${type === TransactionType.EXPENSE ? 'bg-rose-500 shadow-rose-200 hover:bg-rose-600' : 'bg-emerald-500 shadow-emerald-200 hover:bg-emerald-600'}`}
        >
          {editData ? 'Änderungen speichern' : 'Buchung abschließen'}
        </button>
      </form>
    </div>
  );
};

export default TransactionForm;
