
import React, { useMemo, useState } from 'react';
import { Transaction, TransactionType, FamilySettings } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { TrendingUp, TrendingDown, Wallet, PieChart as PieIcon, ChevronLeft, ChevronRight, FileText, Edit2, Trash2, X, Printer, Target, ShieldCheck, AlertCircle } from 'lucide-react';

interface Props {
  transactions: Transaction[];
  onEdit: (t: Transaction) => void;
  onDelete: (id: string) => void;
  settings: FamilySettings;
}

const Dashboard: React.FC<Props> = ({ transactions, onEdit, onDelete, settings }) => {
  const [viewDate, setViewDate] = useState(new Date());
  const [showReport, setShowReport] = useState(false);

  const monthNames = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"];

  const changeMonth = (offset: number) => {
    setViewDate(prev => {
      const d = new Date(prev);
      d.setMonth(d.getMonth() + offset);
      return d;
    });
  };

  const currentMonthTransactions = useMemo(() => {
    const targetMonth = viewDate.getMonth();
    const targetYear = viewDate.getFullYear();
    const startOfCurrentMonth = new Date(targetYear, targetMonth, 1);
    const endOfCurrentMonth = new Date(targetYear, targetMonth + 1, 0);

    return transactions.filter(t => {
      const tDate = new Date(t.date);
      if (t.isRecurring) {
        const startedBeforeOrThisMonth = tDate <= endOfCurrentMonth;
        let activeThisMonth = startedBeforeOrThisMonth;
        if (t.endDate) {
          const endDate = new Date(t.endDate);
          activeThisMonth = startedBeforeOrThisMonth && endDate >= startOfCurrentMonth;
        }
        return activeThisMonth;
      }
      return tDate.getMonth() === targetMonth && tDate.getFullYear() === targetYear;
    });
  }, [transactions, viewDate]);

  const stats = useMemo(() => {
    const income = currentMonthTransactions
      .filter(t => t.type === TransactionType.INCOME)
      .reduce((sum, t) => sum + t.amount, 0);
    const expense = currentMonthTransactions
      .filter(t => t.type === TransactionType.EXPENSE)
      .reduce((sum, t) => sum + t.amount, 0);
    return { income, expense, balance: income - expense };
  }, [currentMonthTransactions]);

  const categoryData = useMemo(() => {
    const categories: Record<string, number> = {};
    currentMonthTransactions
      .filter(t => t.type === TransactionType.EXPENSE)
      .forEach(t => {
        categories[t.category] = (categories[t.category] || 0) + t.amount;
      });
    return Object.entries(categories)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
  }, [currentMonthTransactions]);

  const savingsProgress = Math.min(100, Math.max(0, (stats.balance / (settings.monthlySavingsGoal || 1)) * 100));
  
  // KI-Notgroschen Berechnung (3x durchschnittliche Monatsausgaben)
  const recommendedEmergencyFund = stats.expense > 0 ? stats.expense * 3 : 3000;

  const COLORS = ['#7c3aed', '#10b981', '#f59e0b', '#fb7185', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];
  const formatter = new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' });

  if (showReport) {
    return (
      <div className="fixed inset-0 bg-white z-[100] overflow-y-auto animate-in slide-in-from-bottom-10 duration-500">
        <div className="max-w-4xl mx-auto p-10 space-y-12">
          {/* Header */}
          <div className="flex justify-between items-center border-b pb-8 no-print">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-violet-600 rounded-2xl flex items-center justify-center text-white font-black shadow-lg">€</div>
              <h2 className="text-3xl font-black text-slate-900 tracking-tight">Finanzbericht</h2>
            </div>
            <div className="flex items-center gap-4">
              <button 
                onClick={() => window.print()}
                className="flex items-center gap-2 px-6 py-3 bg-slate-900 text-white rounded-xl font-bold shadow-xl hover:bg-black transition-all"
              >
                <Printer size={18} /> Jetzt Drucken
              </button>
              <button 
                onClick={() => setShowReport(false)}
                className="p-3 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-50 transition-all"
              >
                <X size={24} />
              </button>
            </div>
          </div>

          <div className="space-y-12">
            <header className="text-center space-y-2">
              <h1 className="text-4xl font-black text-slate-900 tracking-tight">Übersicht: Familie {settings.familyName}</h1>
              <p className="text-slate-500 font-bold text-lg uppercase tracking-widest">{monthNames[viewDate.getMonth()]} {viewDate.getFullYear()}</p>
              <div className="flex justify-center gap-4 text-xs font-bold text-slate-400 uppercase tracking-widest mt-4">
                <span>{settings.adults} Erw. / {settings.children} Kind.</span>
                <span>•</span>
                <span>{settings.petCount} Tiere</span>
                <span>•</span>
                <span>{settings.carCount} PKW / {settings.publicTransportSubCount} ÖPNV</span>
              </div>
            </header>

            <div className="grid grid-cols-3 gap-8">
              <div className="p-8 bg-slate-50 rounded-3xl text-center space-y-2 border border-slate-100">
                <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest">Saldo</p>
                <p className={`text-3xl font-black ${stats.balance >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>{formatter.format(stats.balance)}</p>
              </div>
              <div className="p-8 bg-slate-50 rounded-3xl text-center space-y-2 border border-slate-100">
                <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest">Einnahmen</p>
                <p className="text-3xl font-black text-slate-900">{formatter.format(stats.income)}</p>
              </div>
              <div className="p-8 bg-slate-50 rounded-3xl text-center space-y-2 border border-slate-100">
                <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest">Ausgaben</p>
                <p className="text-3xl font-black text-slate-900">{formatter.format(stats.expense)}</p>
              </div>
            </div>

            <div className="space-y-6">
              <h3 className="text-xl font-black text-slate-900 tracking-tight border-b pb-4">Kategorien-Details</h3>
              <div className="grid grid-cols-2 gap-x-12 gap-y-4">
                {categoryData.map((cat) => (
                  <div key={cat.name} className="flex justify-between items-center py-2 border-b border-slate-50">
                    <span className="font-bold text-slate-700">{cat.name}</span>
                    <span className="font-black text-slate-900">{formatter.format(cat.value)}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-6">
              <h3 className="text-xl font-black text-slate-900 tracking-tight border-b pb-4">Alle Buchungen</h3>
              <div className="space-y-2">
                {currentMonthTransactions
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map(t => (
                    <div key={t.id} className="flex justify-between items-center py-3 border-b border-slate-50 text-sm">
                      <div>
                        <p className="font-bold text-slate-900">{t.description}</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase">{t.category} • {new Date(t.date).toLocaleDateString('de-DE')}</p>
                      </div>
                      <span className={`font-black ${t.type === TransactionType.INCOME ? 'text-emerald-600' : 'text-slate-900'}`}>
                        {t.type === TransactionType.EXPENSE ? '-' : '+'}{formatter.format(t.amount)}
                      </span>
                    </div>
                  ))}
              </div>
            </div>

            <footer className="pt-20 text-center border-t border-slate-100">
              <p className="text-slate-400 font-black text-[10px] uppercase tracking-[0.3em]">FamFinance - Euer Familien Haushaltsbuch</p>
            </footer>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 no-print">
        <div>
          <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight">Eure Finanzen</h2>
          <p className="text-slate-500 font-medium mt-1">Überblick für {monthNames[viewDate.getMonth()]} {viewDate.getFullYear()}</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center bg-white rounded-[12px] shadow-sm border border-slate-200 p-1">
            <button onClick={() => changeMonth(-1)} className="p-2 hover:bg-slate-50 rounded-lg transition-all"><ChevronLeft size={20} /></button>
            <div className="px-6 font-bold text-slate-700 min-w-[120px] text-center">{monthNames[viewDate.getMonth()]}</div>
            <button onClick={() => changeMonth(1)} className="p-2 hover:bg-slate-50 rounded-lg transition-all"><ChevronRight size={20} /></button>
          </div>
          <button onClick={() => setShowReport(true)} className="flex items-center justify-center p-3.5 bg-white border border-slate-200 text-slate-600 rounded-[12px] font-bold shadow-sm hover:border-violet-300 hover:text-violet-600 transition-all active:scale-95">
            <FileText size={20} />
          </button>
        </div>
      </header>

      {/* Quick Stats & Savings Tracker */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 no-print">
        <StatCard title="Saldo" amount={formatter.format(stats.balance)} icon={<Wallet className="text-violet-600" />} textColor={stats.balance >= 0 ? "text-emerald-600" : "text-rose-500"} />
        <StatCard title="Einnahmen" amount={formatter.format(stats.income)} icon={<TrendingUp className="text-emerald-500" />} />
        <StatCard title="Ausgaben" amount={formatter.format(stats.expense)} icon={<TrendingDown className="text-rose-500" />} />
        
        <div className="bg-white p-6 rounded-[12px] shadow-sm border border-slate-100 flex flex-col justify-between group hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-2">
             <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest">Sparziel-Tracker</p>
             <Target size={14} className="text-violet-500" />
          </div>
          <div className="space-y-3">
            <div className="flex justify-between items-end">
              <span className="text-xl font-black text-slate-900 tracking-tighter">{savingsProgress.toFixed(0)}%</span>
              <span className="text-[10px] text-slate-400 font-bold">Ziel: {settings.monthlySavingsGoal}€</span>
            </div>
            <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
              <div className="h-full bg-violet-600 transition-all duration-1000" style={{ width: `${savingsProgress}%` }} />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 no-print">
        {/* Categories Analysis */}
        <div className="lg:col-span-2 bg-white p-8 rounded-[12px] shadow-sm border border-slate-100 flex flex-col min-h-[450px]">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-violet-50 text-violet-600 rounded-lg"><PieIcon size={20} /></div>
              <h3 className="font-bold text-slate-800 tracking-tight">Kategorien-Analyse</h3>
            </div>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Ausgaben</span>
          </div>
          
          <div className="flex-1 w-full" style={{ height: '320px', minHeight: '320px' }}>
            {categoryData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryData} layout="vertical" margin={{ left: 0, right: 30, top: 0, bottom: 0 }}>
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" fontSize={11} axisLine={false} tickLine={false} width={80} />
                  <Tooltip cursor={{fill: 'transparent'}} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                  <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={24}>
                    {categoryData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-300 gap-4">
                <PieIcon size={48} strokeWidth={1} />
                <p className="italic font-medium">Noch keine Daten vorhanden</p>
              </div>
            )}
          </div>
        </div>

        {/* AI Insight Box & emergency fund */}
        <div className="space-y-6">
          <div className="bg-gradient-to-br from-indigo-600 to-violet-700 p-8 rounded-[12px] shadow-xl text-white space-y-6 relative overflow-hidden">
            <ShieldCheck className="absolute -right-4 -bottom-4 w-32 h-32 opacity-10" />
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm"><AlertCircle size={20} /></div>
              <h3 className="font-bold tracking-tight">Mentor Tipp</h3>
            </div>
            <div className="space-y-4 relative z-10">
              <p className="text-sm font-medium leading-relaxed">
                Basierend auf euren Ausgaben sollte euer Notgroschen idealerweise bei <span className="font-black underline underline-offset-4 decoration-indigo-300">{formatter.format(recommendedEmergencyFund)}</span> liegen.
              </p>
              {settings.housingSituation === 'Eigenheim' && (
                <div className="pt-4 border-t border-white/20">
                  <p className="text-[10px] font-black uppercase tracking-widest opacity-80 mb-1">Eigenheim-Check</p>
                  <p className="text-xs leading-relaxed font-medium">
                    Plane zusätzlich monatlich ca. 1,50€ pro m² für Instandhaltungen ein.
                  </p>
                </div>
              )}
            </div>
          </div>

          <div className="bg-white p-6 rounded-[12px] shadow-sm border border-slate-100">
            <h3 className="text-sm font-bold text-slate-800 mb-4">Letzte Transaktionen</h3>
            <div className="space-y-3">
              {currentMonthTransactions
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .slice(0, 5)
                .map(t => (
                  <div key={t.id} className="flex justify-between items-center text-xs">
                    <span className="font-medium text-slate-600 truncate max-w-[120px]">{t.description}</span>
                    <span className={`font-bold ${t.type === TransactionType.INCOME ? 'text-emerald-600' : 'text-slate-900'}`}>
                      {t.type === TransactionType.EXPENSE ? '-' : '+'}{formatter.format(t.amount)}
                    </span>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, amount, icon, textColor = "text-slate-900" }: { title: string, amount: string, icon: React.ReactNode, textColor?: string }) => (
  <div className="bg-white p-6 rounded-[12px] shadow-sm border border-slate-100 flex items-center justify-between group hover:shadow-md transition-shadow">
    <div>
      <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest mb-1">{title}</p>
      <p className={`text-xl font-black ${textColor} tracking-tighter`}>{amount}</p>
    </div>
    <div className="p-3 bg-slate-50 rounded-xl group-hover:bg-white transition-colors border border-transparent group-hover:border-slate-50">{icon}</div>
  </div>
);

export default Dashboard;
