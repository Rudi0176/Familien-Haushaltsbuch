
import React, { useState, useRef, useEffect } from 'react';
import { FamilySettings } from '../types';
import { getOnboardingResponse } from '../services/gemini';
import { Sparkles, Send, Loader2, Bot, User, CheckCircle2 } from 'lucide-react';

interface Props {
  onComplete: (settings: FamilySettings) => void;
}

interface Message {
  role: 'user' | 'model';
  text: string;
}

const OnboardingWizard: React.FC<Props> = ({ onComplete }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [isFinished, setIsFinished] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Start greeting
    const startGreeting = async () => {
      setLoading(true);
      const res = await getOnboardingResponse([{ role: 'user', parts: [{ text: "Hallo! Ich möchte das Onboarding starten." }] }]);
      if (res) setMessages([{ role: 'model', text: res }]);
      setLoading(false);
    };
    startGreeting();
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || loading) return;

    const newMessages: Message[] = [...messages, { role: 'user', text: inputText }];
    setMessages(newMessages);
    setInputText('');
    setLoading(true);

    const res = await getOnboardingResponse(newMessages.map(m => ({ role: m.role, parts: [{ text: m.text }] })));
    
    if (res) {
      // Check for JSON block
      const jsonMatch = res.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        try {
          const finalData = JSON.parse(jsonMatch[0]);
          const cleanedText = res.replace(jsonMatch[0], '').trim();
          setMessages(prev => [...prev, { role: 'model', text: cleanedText }]);
          setIsFinished(true);
          
          // Delay completion slightly for user to read final message
          setTimeout(() => {
            onComplete(finalData);
          }, 3000);
        } catch (e) {
          setMessages(prev => [...prev, { role: 'model', text: res }]);
        }
      } else {
        setMessages(prev => [...prev, { role: 'model', text: res }]);
      }
    }
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-[#f8fafc] z-[200] flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-white rounded-[24px] shadow-2xl border border-slate-100 flex flex-col h-[85vh] overflow-hidden animate-in zoom-in-95 duration-500">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-violet-600 to-indigo-700 p-6 text-white flex items-center gap-4 shrink-0">
          <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
            <Sparkles size={24} />
          </div>
          <div>
            <h2 className="font-black text-xl tracking-tight">Euer Finanz-Coach</h2>
            <p className="text-xs text-white/70 font-bold uppercase tracking-widest">Gemeinsam zum Sparziel</p>
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
          {messages.map((m, i) => (
            <div key={i} className={`flex gap-4 ${m.role === 'user' ? 'flex-row-reverse' : ''} animate-in fade-in slide-in-from-bottom-4`}>
              <div className={`shrink-0 w-10 h-10 rounded-xl flex items-center justify-center ${m.role === 'model' ? 'bg-violet-50 text-violet-600' : 'bg-slate-100 text-slate-500'}`}>
                {m.role === 'model' ? <Bot size={20} /> : <User size={20} />}
              </div>
              <div className={`max-w-[85%] p-4 rounded-2xl leading-relaxed text-sm md:text-base font-medium ${m.role === 'model' ? 'bg-slate-50 text-slate-800 rounded-tl-none border border-slate-100' : 'bg-violet-600 text-white rounded-tr-none shadow-lg shadow-violet-100'}`}>
                <p className="whitespace-pre-line">{m.text}</p>
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex gap-4 animate-pulse">
              <div className="shrink-0 w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-300">
                <Loader2 size={20} className="animate-spin" />
              </div>
              <div className="bg-slate-50 h-12 w-2/3 rounded-2xl rounded-tl-none border border-slate-100" />
            </div>
          )}
          {isFinished && (
            <div className="flex justify-center pt-4">
              <div className="flex items-center gap-3 bg-emerald-50 text-emerald-700 px-6 py-4 rounded-2xl border border-emerald-100 animate-bounce">
                <CheckCircle2 size={24} />
                <span className="font-bold">Perfekt! Profil ist gespeichert.</span>
              </div>
            </div>
          )}
          <div ref={scrollRef} />
        </div>

        {/* Input */}
        {!isFinished && (
          <form onSubmit={handleSend} className="p-6 bg-slate-50 border-t border-slate-100 flex gap-3">
            <input 
              type="text" 
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              disabled={loading}
              placeholder="Deine Antwort..."
              className="flex-1 px-5 py-4 rounded-xl border-2 border-transparent focus:border-violet-500 focus:bg-white outline-none transition-all font-semibold shadow-sm"
            />
            <button 
              type="submit"
              disabled={loading || !inputText.trim()}
              className="bg-violet-600 text-white p-4 rounded-xl shadow-lg shadow-violet-100 hover:bg-violet-700 active:scale-95 transition-all disabled:opacity-50"
            >
              <Send size={24} />
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default OnboardingWizard;
