
import React, { useMemo, useState } from 'react';
import { Transaction, TransactionType, FamilySettings } from '../types.ts';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Calendar, TrendingUp, TrendingDown, PiggyBank, ArrowDownRight, CreditCard, Info } from 'lucide-react';

interface Props {
  transactions: Transaction[];
  settings: FamilySettings;
}

const YearlyOverview: React.FC<Props> = ({ transactions, settings }) => {
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  
  const years = useMemo(() => {
    const yearsSet = new Set<number>();
    yearsSet.add(new Date().getFullYear());
    transactions.forEach(t => yearsSet.add(new Date(t.date).getFullYear()));
    return Array.from(yearsSet).sort((a, b) => b - a);
  }, [transactions]);

  const monthNames = ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];

  const yearlyData = useMemo(() => {
    const data = monthNames.map(name => ({
      name,
      Einnahmen: 0,
      Ausgaben: 0,
    }));

    transactions.forEach(t => {
      const tDate = new Date(t.date);
      const isRecurring = t.isRecurring;
      
      for (let m = 0; m < 12; m++) {
        const monthStart = new Date(selectedYear, m, 1);
        const monthEnd = new Date(selectedYear, m + 1, 0);

        let isActive = false;
        if (isRecurring) {
          const startedBeforeOrThisMonth = tDate <= monthEnd;
          isActive = startedBeforeOrThisMonth;
          if (t.endDate) {
            const endDate = new Date(t.endDate);
            isActive = startedBeforeOrThisMonth && endDate >= monthStart;
          }
        } else {
          isActive = tDate.getFullYear() === selectedYear && tDate.getMonth() === m;
        }

        if (isActive) {
          if (t.type === TransactionType.INCOME) {
            data[m].Einnahmen += t.amount;
          } else {
            data[m].Ausgaben += t.amount;
          }
        }
      }
    });

    return data;
  }, [transactions, selectedYear]);

  const stats = useMemo(() => {
    const totalIncome = yearlyData.reduce((sum, d) => sum + d.Einnahmen, 0);
    const totalExpense = yearlyData.reduce((sum, d) => sum + d.Ausgaben, 0);
    
    const annualInterest = settings.debtAmount * (settings.interestRate / 100);
    const dailyInterest = annualInterest / 365;

    return {
      totalIncome,
      totalExpense,
      balance: totalIncome - totalExpense,
      avgExpense: totalExpense / 12,
      annualInterest,
      dailyInterest
    };
  }, [yearlyData, settings]);

  const formatter = new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' });

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight">Jahresrückblick</h2>
          <p className="text-slate-500 font-medium mt-1">Zusammenfassung für das Jahr {selectedYear}</p>
        </div>

        <div className="flex items-center bg-white rounded-[12px] shadow-sm border border-slate-200 p-1">
          <Calendar size={18} className="ml-3 text-slate-400" />
          <select 
            value={selectedYear}
            onChange={(e) => setSelectedYear(Number(e.target.value))}
            className="bg-transparent px-4 py-2.5 font-bold text-slate-700 outline-none appearance-none cursor-pointer"
          >
            {years.map(y => <option key={y} value={y}>{y}</option>)}
          </select>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <YearCard title="Jahres-Einnahmen" amount={formatter.format(stats.totalIncome)} icon={<TrendingUp className="text-emerald-500" />} />
        <YearCard 
          title="Jahres-Ausgaben" 
          amount={formatter.format(stats.totalExpense)} 
          icon={<TrendingDown className="text-rose-500" />} 
          trend={<span className="flex items-center text-rose-500 text-[10px] font-black uppercase tracking-tighter"><ArrowDownRight size={10}/> {formatter.format(stats.avgExpense)} / Mon</span>}
        />
        <YearCard title="Netto Ersparnis" amount={formatter.format(stats.balance)} icon={<PiggyBank className="text-white" />} highlight={true} />
      </div>

      {settings.debtAmount > 0 && (
        <div className="bg-amber-50 border border-amber-100 p-8 rounded-[12px] grid grid-cols-1 md:grid-cols-3 gap-8 items-center shadow-inner">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-amber-800">
               <CreditCard size={20} />
               <h3 className="font-black uppercase tracking-widest text-sm">Schulden-Check</h3>
            </div>
            <p className="text-xs text-amber-700 font-medium leading-relaxed">
              Bei einer Restschuld von {formatter.format(settings.debtAmount)} und {settings.interestRate}% Zinsen verliert ihr Geld.
            </p>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-amber-100 text-center">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Zinsverlust / Tag</p>
            <p className="text-2xl font-black text-rose-500 tracking-tighter">{formatter.format(stats.dailyInterest)}</p>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-amber-100 text-center">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Zinsverlust / Jahr</p>
            <p className="text-2xl font-black text-rose-500 tracking-tighter">{formatter.format(stats.annualInterest)}</p>
          </div>
        </div>
      )}

      <div className="bg-white p-8 rounded-[12px] shadow-sm border border-slate-100">
        <div className="flex items-center justify-between mb-8">
          <h3 className="font-bold text-slate-800 tracking-tight flex items-center gap-2">
            <TrendingUp size={20} className="text-violet-500" />
            Monatlicher Trend {selectedYear}
          </h3>
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Einnahmen vs Ausgaben</span>
        </div>
        
        <div className="w-full" style={{ height: '400px', minHeight: '400px' }}>
          <ResponsiveContainer width="100%" height="100%" aspect={2.5}>
            <BarChart data={yearlyData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="name" fontSize={11} axisLine={false} tickLine={false} tick={{fill: '#94a3b8'}} />
              <YAxis fontSize={10} axisLine={false} tickLine={false} tick={{fill: '#94a3b8'}} tickFormatter={(val) => `${val}€`} />
              <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
              <Legend iconType="circle" wrapperStyle={{ paddingTop: '24px', fontSize: '11px', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: '0.05em' }} />
              <Bar dataKey="Einnahmen" fill="#10b981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Ausgaben" fill="#fb7185" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

const YearCard = ({ title, amount, icon, highlight = false, trend }: any) => (
  <div className={`p-8 rounded-[12px] shadow-sm border transition-all hover:shadow-md flex items-center justify-between ${highlight ? 'bg-violet-600 text-white border-violet-500 shadow-violet-100' : 'bg-white border-slate-100 text-slate-900'}`}>
    <div className="space-y-1">
      <p className={`text-[10px] font-black uppercase tracking-widest ${highlight ? 'text-violet-200' : 'text-slate-400'}`}>{title}</p>
      <p className="text-3xl font-black tracking-tighter">{amount}</p>
      {trend && trend}
    </div>
    <div className={`p-4 rounded-xl ${highlight ? 'bg-white/15 text-white' : 'bg-slate-50 text-slate-400'}`}>
      {icon}
    </div>
  </div>
);

export default YearlyOverview;
